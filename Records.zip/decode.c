#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "encode.h"
#include "function_q2.h"
#include "flags.h"
/*==============================================================================*/
#define SUCCESS 0
#define MATCH 0
#define FAIL -1
#define MAX 25
/*==============================================================================*/
int main (int argc, char *argv[]) {

  int i,j;

  char input_file[200];
  char output_file[200];
  char *contents;

  int *text_freq;
  int num_letters = 0;
  int shift = 0;
  int decode = 0;

  int input_exist = FAIL;
  int output_exist = FAIL;

  char s_exist[5];
  char S_exist[5];
  char n_exist[5];
  char x_exist[5];
  char t_exist[5];

  for (i = 0; i < argc; i++) {

      if (strcmp(argv[i],"-F") == MATCH ) {
         strcpy(input_file, argv[i+1]);
         input_exist = SUCCESS;
      }

      if (strcmp(argv[i],"-O") == MATCH) {
         strcpy(output_file, argv[i+1]);
         output_exist = SUCCESS;
      }

      if (strncmp(&argv[i][0],"-",1) == MATCH) {
           int len =   strlen(argv[i]);
           for (j = 1; j <  len; j++) {
                 if (argv [i][j] == 's') {
                    strcpy (s_exist, "s");
                 }
                 if (argv [i][j] == 'S') {
                    strcpy (S_exist, "S");
                 }
                 if (argv[i][j] == 't') {
                    strcpy (t_exist, "t");
                  }
                  if (argv[i][j] == 'x') {
                    strcpy (x_exist, "x");
                  }
                   if (argv[i][j] == 'n'){
                    strcpy (n_exist, "n");
                  }
             }
        }

  } /* end of loop for arguments */

  if (s_exist == SUCCESS && S_exist == SUCCESS){
    printf("Error Invalid flag usage. Can't use -s and -S at the same time");
    exit(-1);
  }

 if (input_exist == SUCCESS && output_exist == SUCCESS) {
    contents = read_file(input_file);
    num_letters = letter_count (contents);
    text_freq =  freq_table();
    add_letters(text_freq, contents);

    shift = encode_shift(contents);
    decode = to_decode(shift);

    if ( strcmp (s_exist, "s") == MATCH) { /*prints shift used to decode */
         printf("decoded shift = %d\n", decode);
     } else if (strcmp (S_exist, "S") == MATCH) { /*prints shift used to encode */
         printf("encoded shift = %d\n", shift);
     }

    if (strcmp (t_exist, "t") == MATCH && strcmp (x_exist, "x") == MATCH) { /* prints the char/letter count and freq table */
       printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
       printf("The number of letters are: %d\n",num_letters);
       putchar('\n');
       printf("shift  => chi_square(shift)\n");/* headers */
       encode_shift_print(contents);
       print_table(text_freq);
    } else if (strcmp (t_exist, "t") == MATCH && strcmp (x_exist, "x") != MATCH) {  /* prints the char/letter count and freq table */
      printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
      printf("The number of letters are: %d\n",num_letters);
      print_table(text_freq);
    }
    putchar('\n');
    copy_file_decode (input_file, output_file, decode);

  }

  if (input_exist == SUCCESS && output_exist == FAIL) {
        contents = read_file(input_file);
        num_letters = letter_count (contents);
        text_freq =  freq_table();
        add_letters(text_freq, contents);

        shift = encode_shift(contents);
        decode = to_decode(shift);

       if ( strcmp (s_exist, "s") == MATCH) { /*prints shift used to decode */
            printf("decoded shift = %d\n", decode);
        } else if (strcmp (S_exist, "S") == MATCH) { /*prints shift used to encode */
            printf("encoded shift = %d\n", shift);
        }

       if (strcmp (t_exist, "t") == MATCH && strcmp (x_exist, "x") == MATCH) { /* prints the char/letter count and freq table */
          printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
          printf("The number of letters are: %d\n",num_letters);
          putchar('\n');
          printf("shift  => chi_square(shift)\n");/* headers */
          encode_shift_print(contents);
          print_table(text_freq);
       } else if (strcmp (t_exist, "t") == MATCH && strcmp (x_exist, "x") != MATCH) {  /* prints the char/letter count and freq table */
         printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
         printf("The number of letters are: %d\n",num_letters);
         print_table(text_freq);
       }

       if (strcmp (n_exist, "n") != MATCH) { /* supresses from printing to stdout */
           printf("\n");
           printf("Decoded Message:\n");
           file_std_out (contents, decode);
        }


  }

  if (input_exist == FAIL && output_exist == FAIL) {
    contents = std_in(); /* read from stdout */
    num_letters = letter_count (contents);
    text_freq=  freq_table();
    add_letters(text_freq, contents);


    shift = encode_shift(contents);
    decode = to_decode(shift);

    putchar('\n');
    putchar('\n');
    if ( strcmp (s_exist, "s") == MATCH) { /*prints shift used to decode */
         printf("decoded shift = %d\n", decode);
     } else if (strcmp (S_exist, "S") == MATCH) { /*prints shift used to encode */
         printf("encoded shift = %d\n", shift);
     }

    if (strcmp (t_exist, "t") == MATCH && strcmp (x_exist, "x") == MATCH) { /* prints the char/letter count and freq table */
      printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
      printf("The number of letters are: %d\n",num_letters);
       putchar('\n');
       printf("shift  => chi_square(shift)\n");/* headers */
       encode_shift_print(contents);
       print_table(text_freq);
    } else if (strcmp (t_exist, "t") == MATCH && strcmp (x_exist, "x") != MATCH) {  /* prints the char/letter count and freq table */
      printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
      printf("The number of letters are: %d\n",num_letters);
      print_table(text_freq);
    }
    printf("\n");
    if (strcmp (n_exist, "n") != MATCH) { /* if n_exist then it will surpress it from printing to stdout */
        printf("Decoded Message:\n");
        std_out (contents, decode);
     }

    putchar ('\n');



  }

  if (input_exist == FAIL && output_exist == SUCCESS) {
    contents = std_in(); /* read from stdout */
    num_letters = letter_count (contents);
    text_freq=  freq_table();
    add_letters(text_freq, contents);

    shift = encode_shift(contents);
    decode = to_decode(shift);

    putchar('\n');
    putchar('\n');
    if ( strcmp (s_exist, "s") == MATCH) { /*prints shift used to decode */
         printf("decoded shift = %d\n", decode);
     } else if (strcmp (S_exist, "S") == MATCH) { /*prints shift used to encode */
         printf("encoded shift = %d\n", shift);
     }

    if (strcmp (t_exist, "t") == MATCH && strcmp (x_exist, "x") == MATCH) { /* prints the char/letter count and freq table */
       printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
       printf("The number of letters are: %d\n",num_letters);
       putchar('\n');
       printf("shift  => chi_square(shift)\n");/* headers */
       encode_shift_print(contents);
       print_table(text_freq);
    } else if (strcmp (t_exist, "t") == MATCH && strcmp (x_exist, "x") != MATCH) {  /* prints the char/letter count and freq table */
      printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
      printf("The number of letters are: %d\n",num_letters);
      print_table(text_freq);
    }
    putchar ('\n');

    stdin_file_decode(output_file,contents, decode); /*take in contents and print to output_file*/

  }



  free(contents);





  return (SUCCESS);
}

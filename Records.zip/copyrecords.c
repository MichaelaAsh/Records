#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*==============================================================================*/
#include "structure.h"
#include "encode.h"
#include "function_q2.h"
#include "flags.h"
#include "binary.h"
/*==============================================================================*/
#define SUCCESS 0
#define MATCH 0
#define FAIL -1
#define MAX 25
/*==============================================================================*/
int main (int argc, char *argv[]) {

  char input_file[200];
  char output_file[200];
  char reference_file[200];

  char *contents;
  int i;
  int shift = 0;
  int decode = 0;

  int *text_freq;

  int input_exist = FAIL;
  int output_exist = FAIL;
  int reference_exist = FAIL;

  for (i = 0; i < argc; i++) {

      if (strcmp(argv[i],"-F") == MATCH ) { /* check for input file flag */
         strcpy(input_file, argv[i+1]);
         input_exist = SUCCESS;
      } else if (strcmp(argv[i],"-O") == MATCH) { /* checks the ouput file flag */
         strcpy(output_file, argv[i+1]);
         output_exist = SUCCESS;
      } else if (strcmp(argv[i],"-D") == MATCH) {/*checks the reference file flag */
         strcpy(reference_file, argv[i+1]);
         reference_exist = SUCCESS;
      } else if (strcmp(argv[i],"-r") == MATCH) { /* check if you should copy the file in reverse ordr */
         printf("Error: Unable to reverse copy\n");
         exit(-1);
      }

  } /* end of loop for arguments */

  if (reference_exist == FAIL) {
    printf("Error: No Refernce File\n");
    exit (-1);
  }

  if (input_exist == FAIL) {
    printf("Error: No input File\n");
    exit (-1);
  }



  if (input_exist == SUCCESS && output_exist == SUCCESS) { /* input file to out file */
    contents = read_file(reference_file);
    text_freq =  freq_table();
    add_letters(text_freq, contents);

    shift = encode_shift(contents);
    decode = to_decode(shift);

    int i;
    FILE *fp = fopen (input_file, "rb");
    int size_of_file = file_size(fp);
    fclose (fp);

      Record *ptr;
      contents =  binary_read_all (input_file);
      ptr = binary_read_file(input_file);


       fp = fopen (output_file, "wb");

        for (i = 0; contents[i] != EOF; i++) {
          ptr -> characters  =  contents[i];
          ptr -> characters = encode( ptr -> characters, decode);
          contents[i] = ptr -> characters;
        }

        fwrite(contents, sizeof(char), size_of_file, fp);
        fclose (fp);

  }

  if (input_exist == SUCCESS && output_exist == FAIL) { /* input to stdout */
    contents = read_file(reference_file);
    text_freq =  freq_table();
    add_letters(text_freq, contents);

    shift = encode_shift(contents);
    decode = to_decode(shift);

    binary_stdout(input_file, decode);

  }


  return(SUCCESS);
}

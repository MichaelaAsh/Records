/*==============================================================================*/
/*takes input from file and prints to stdout */
char  *binary_read_all( char *original_input) {

  FILE *input_file = fopen (original_input, "r");
  int size_of_file = file_size(input_file);

  if (input_file == NULL) { /* error check */
    printf("Invalid File\n");
    exit (FAIL);
  }
   char *contents = malloc (sizeof(char)  * size_of_file);
  fread (contents, sizeof(char), size_of_file , input_file);


  fclose (input_file);

  return contents;

}
/*==============================================================================*/
/*takes input from file and prints to stdout */
Record *binary_read_file( char *original_input) {

  FILE *input_file = fopen (original_input, "rb");

  if (input_file == NULL) { /* error check */
    printf("Invalid File\n");
    exit (FAIL);
  }

  Record  *new_record  = malloc (sizeof(Record));
  fread (new_record, sizeof(Record), 1 , input_file);


  fclose (input_file);

  return new_record;
}
/*==============================================================================*/
/*takes input from file and prints to stdout */
void binary_stdout( char *original_input, int decode) {

  FILE *input_file = fopen (original_input, "rb");
  int size_of_file = file_size(input_file);

  if (input_file == NULL ) { /* error check */
    printf("Invalid File\n");
    exit (FAIL);
  }


  char *content = malloc (sizeof(char)*size_of_file);  /* change 100 later to size_of_file */

  fread (content, sizeof(int), size_of_file, input_file);
  int i = 0;

   while (content[i] != EOF) {
    fputc ( encode(content[i], decode), stdout);
    i++;
  }
  putchar('\n');
  printf("Message Decoded \n");

  fclose (input_file);

  free(content); 

}

/*==============================================================================*/

#define FAIL -1
#define ENTER 10

#define L_A 97
#define L_Z 122
#define U_A 65
#define U_Z 90
#define MAX_SHIFT 13
#define ENDOFALPH 26

char  encode (char contents, int shift ) { /* only works for number below 13  that are positive */

    if (shift > 13) {

              char apply_cipher;
              int corrector= 0;

                if (shift > MAX_SHIFT) {
                   corrector = shift - MAX_SHIFT;
                }

                if (contents >= L_A  && contents <= L_Z ) {

                    apply_cipher = contents + shift;
                    if (apply_cipher <= (-121+corrector)|| apply_cipher >= L_Z) {
                        apply_cipher = apply_cipher - ENDOFALPH;
                     }

                    if (apply_cipher < L_A) {
                        apply_cipher = apply_cipher + ENDOFALPH;
                    }

                } else if (contents >= U_A  && contents <= U_Z) {

                    apply_cipher = contents + shift;
                    if (apply_cipher > U_Z) {
                       apply_cipher = apply_cipher - ENDOFALPH;
                       putchar('\n');
                    }

                } else {
                  apply_cipher = contents;
                }

                contents = apply_cipher;

    } else  if (shift >= 0 && shift <= 13){
            char apply_cipher;

            if (contents >= L_A  && contents <= L_Z ) {
                apply_cipher = contents + shift;
                if (apply_cipher <= -121 || apply_cipher >= L_Z) {
                    apply_cipher = apply_cipher - ENDOFALPH;
                }
                if (apply_cipher < L_A) {
                    apply_cipher = apply_cipher + ENDOFALPH;
                }

            } else if (contents >= U_A  && contents <= U_Z) {
                apply_cipher = contents + shift;
                if (apply_cipher > U_Z) {
                   apply_cipher = apply_cipher - ENDOFALPH;
                }

            } else {
              apply_cipher = contents;
            }

            contents = apply_cipher;

    } else if (shift < 0) {

          if (contents >= L_A && contents <= L_Z) {
              contents = contents + shift;
              if (contents > L_Z) {
                  contents = contents - L_Z + L_A - 1;
              } else if(contents < L_A) {
                  contents  = contents + ENDOFALPH;
              }

          } else if (contents >= U_A && contents <= U_Z) {
              contents = contents + shift;
              if (contents > U_Z) {
                  contents = contents - U_Z + U_A - 1;
              } else if(contents < U_A) {
                  contents = contents + ENDOFALPH;
              }

          }


    }

  return contents;
}

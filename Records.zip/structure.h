

struct info {

   char characters;
   struct info *new_record;
};

typedef struct info Record;

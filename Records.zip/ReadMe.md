## There are three programs

## frequency_table: 
prints the number of times a letter occurred in a file/ stdin

## decode: 
takes in the flags -x, -n,-t, -s, -S -F and -O: decodes a file/stdin and prints to file/stdout
The max characters the program can take in is 200

## copyrecords: 
copies a binary file and write to stdin/ file. This program is incomplete but runs. 

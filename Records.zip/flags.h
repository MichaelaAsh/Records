#define FAIL -1
#define ENTER 10

#define L_A 97
#define L_Z 122
#define U_A 65
#define U_Z 90
#define ENDOFALPH 26
/*==============================================================================*/
int file_size(FILE *fp) {

    int sz = 0;
    fseek (fp, 0L, SEEK_END);
    sz = ftell(fp);
    rewind(fp);
    return sz;
 };
/*==============================================================================*/
/*takes input from file and prints to stdout */
char *read_file( char *original_input) {

  FILE *input_file = fopen (original_input, "r");
  int size_of_file = file_size(input_file);

  if (input_file == NULL) { /* error check */
    printf("Invalid File\n");
    exit (FAIL);
  }


  char *content = malloc (sizeof(char)*size_of_file);  /* change 100 later to size_of_file */
  int i = 0;

  content[i] = fgetc (input_file);

  while (content[i] != EOF) {
    i++;
    content[i] = fgetc (input_file);
  }
  content[i] = '\0';
  fclose (input_file);

  return content;

}
/*==============================================================================*/
char *std_in () { /* takes input from stdin */

  char *contents = malloc (sizeof(char)*200); /*free later */
  int i = 0;
  contents[i]= fgetc (stdin);

  while (contents[i] != EOF) {
    i++;
    contents[i] = fgetc (stdin);
  }

  i++;
  contents[i] = '\0';

  return contents;
}
/*==============================================================================*/
/*takes input from file and prints to stdout */
void file_std_out ( char *content, int shift) {

  char encoded;
  int i = 0;

  while (content[i] != '\0') {
    encoded = encode (content[i], shift);
    printf("%c", encoded);
    i++;
  }

}
/*==============================================================================*/
/*prints to stdout */
void std_out ( char *content, int shift) {

  char encoded;
  int i = 0;

  while (content[i] != EOF) {
    encoded = encode (content[i], shift);
    printf("%c", encoded);
    i++;
  }

}
/*==============================================================================*/
/* takes input from file and writes to another file */
void copy_file_decode (char *original_input, char *copy_input, int shift) {

  FILE *original_text = fopen (original_input, "r");
  FILE *copy_text = fopen (copy_input, "w");

  if (original_text == NULL || copy_text == NULL) { /* error check */
    printf("Invalid File\n");
    exit (FAIL);
  }

  char contents;
  char encoded;

  contents = fgetc (original_text);


  while (contents != EOF) {
    encoded = encode(contents, shift);
    fputc (encoded, copy_text);
    contents = fgetc (original_text);
  }

  printf("File Decoded \n");

   fclose (copy_text);
   fclose (original_text);

}
/*==============================================================================*/
/* takes input from file and writes to another file */
void stdin_file_decode (char *copy_input, char *content, int shift) {

  FILE *copy_text = fopen (copy_input, "w");

  if (copy_text == NULL) { /* error check */
    printf("Invalid File\n");
    exit (FAIL);
  }

  char encoded;
  int i = 0;

  while (content[i] != EOF) {
    encoded = encode (content[i], shift);
    fputc (encoded, copy_text);
    i++;
  }

  fclose (copy_text);
}
/*==============================================================================*/

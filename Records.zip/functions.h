#define FAIL -1
#define ENTER 10

#define L_A 97
#define L_Z 122
#define U_A 65
#define U_Z 90
#define ENDOFALPH 26
/*==============================================================================*/
int file_size(FILE *fp) {

    int sz = 0;
    fseek (fp, 0L, SEEK_END);
    sz = ftell(fp);
    rewind(fp);
    return sz;
 };
/*==============================================================================*/
/*takes input from file and prints to stdout */
char *read_and_copy_stdout( char *original_input) {

  FILE *input_file = fopen (original_input, "r");
  int size_of_file = file_size(input_file);

  if (input_file == NULL) { /* error check */
    printf("Invalid File\n");
    exit (FAIL);
  }


  char *content = malloc (sizeof(char)*size_of_file);  /* change 100 later to size_of_file */
  int i = 0;

  content[i] = fgetc (input_file);

  while (content[i] != EOF) {
    i++;
    content[i] = fgetc (input_file);
  }
  content[i] = '\0';
  fclose (input_file);

  return content;

}
/*==============================================================================*/
char *stdin_stdout () { /* takes input from stdin and prints from stdin */

  char *contents = malloc (sizeof(char)*200); /*free later */
  int i = 0;
  contents[i]= fgetc (stdin);

  while (contents[i] != ENTER) {
    i++;
    contents[i] = fgetc (stdin);
  }


  i++;
  contents[i] = '\0';

  return contents;
}
/*==============================================================================*/
int letter_count ( char *contents) {

  int i = 0;
  int count = 0;

  for (i = 0; contents[i] != '\0'; i++) { /* Remember to count for chars A to Z */
      if ( (contents[i] >= L_A && contents[i] <= L_Z) || (contents[i] >= U_A && contents[i] <= U_Z) ) {
        count++;
      }
  }

return count;
}

/*==============================================================================*/
int *freq_table() {

  int *freq_array = malloc (sizeof(int)*26);
  return freq_array;

}

/*==============================================================================*/
void add_letters( int*freq_table, char *string) {

 int i = 0;
 int letter_index = 0;
 int num_of_matches = 0;
 int increase = 0;

 while ( letter_index < ENDOFALPH) {
        while (string[i] != '\0') {
          if ( (string[i] >= L_A && string[i] <= L_Z )|| (string[i] >= U_A && string[i] <= U_Z) ) {/*makes sure it's a letter first */
                if (string[i] == L_A + increase || string[i] == U_A + increase) { /*gradually goes through the alpahbet */
                  num_of_matches++;
                }
                i++;
            } else {
              i++;
            }
         }

        freq_table[letter_index] = num_of_matches;

        increase++; /* goes to next alphabet */
        i = 0;
        num_of_matches = 0;
        letter_index++; /*index changes to the next alphabet */

   }



}

/*==============================================================================*/
void print_table (int *freq_table) {

  char letter = U_A;
  int i;

  putchar('\n');
  printf("Letter\t Letter Counts\n");/* headers */

   for (i = 0; i < 26; i++) {
        printf("%3c\t%3d\n", letter, freq_table[i]);
        letter++;
   }


}

/*==============================================================================*/

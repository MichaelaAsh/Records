#include <stdio.h>
#include <stdlib.h>
#include "functions.h"
#include <string.h>

#define SUCCESS 0
#define FAIL -1
int main (int argc, char *argv[]) {

  char input_file[200];
  char *contents;
  int *freq_array;
  int num_letters;

  if ( argc >= 3) {

       if (strcmp(argv[1],"-F") == 0) {
          strcpy(input_file, argv[2]);
       }


       contents= read_and_copy_stdout (input_file);  /* read file */
       num_letters = letter_count (contents);
       freq_array =  freq_table();
       add_letters(freq_array, contents);

       printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
       printf("The number of letters are: %d\n",num_letters);

       print_table(freq_array);



  } else if (argc >= 1) {
       contents = stdin_stdout(); /* read from stdout */
       num_letters = letter_count(contents);
       freq_array = freq_table();
       add_letters(freq_array, contents);

       printf("The number of characters are: %2ld\n", strlen(contents));         /* prints the chi_squared table */
       printf("The number of letters are: %d\n",num_letters);

        print_table(freq_array);


  } else {
    return (FAIL);
  }




  return (SUCCESS);
}
